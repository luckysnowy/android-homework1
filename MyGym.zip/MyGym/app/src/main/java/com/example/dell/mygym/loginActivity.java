package com.example.dell.mygym;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.View.OnClickListener;
public class loginActivity extends AppCompatActivity {

    private Button bt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        bt=(Button) findViewById(R.id.log);

        bt.setOnClickListener(new OnClickListener(){
            @Override
            public  void onClick(View v){
                Intent intent=new Intent(loginActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });

    }

}
